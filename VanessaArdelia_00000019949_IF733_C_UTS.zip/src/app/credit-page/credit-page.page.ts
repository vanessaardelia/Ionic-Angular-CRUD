import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credit-page',
  templateUrl: './credit-page.page.html',
  styleUrls: ['./credit-page.page.scss'],
})
export class CreditPagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
